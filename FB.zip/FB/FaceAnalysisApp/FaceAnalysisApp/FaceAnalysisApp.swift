import SwiftUI

@main
struct FaceAnalysisApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
