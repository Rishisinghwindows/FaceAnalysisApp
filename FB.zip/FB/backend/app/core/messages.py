"""Shared human-readable message constants."""

LOGIN_INVALID_CREDENTIALS = "Invalid email or password."
LOGIN_GENERIC_ERROR = "Unable to sign in right now. Please try again later."
